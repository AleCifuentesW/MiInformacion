public class MiInformacion {
    public static void main(String[] args) {
        System.out.println("Hola, mi nombre es Alexandra Cifuentes.");
        System.out.println("Tengo 37 años de edad.");
        System.out.println("Soy de Chile y vivo en la ciudad de Santiago.");
        System.out.println("Me gusta programar y mirar el cielo estrellado.");
    }
}
